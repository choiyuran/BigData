#파일명 : exercise_solution.py
from selenium import webdriver
from selenium.webdriver.common.keys import Keys 

driver = webdriver.Chrome('C:/Temp/chromedriver')

driver.get('https://map.naver.com/v5/search#driver.get')#('https://map.naver.com/') 
import time
time.sleep(2)
#target=driver.find_element_by_css_selector("#input_popup_selector")
#target.click()
#time.sleep(2)

target=driver.find_element_by_css_selector(".input_search")

target.send_keys('서울시어린이도서관')
target.send_keys(Keys.ENTER)

time.sleep(2)
page = 2
print("1 페이지") 
while True :
    names = driver.find_elements_by_css_selector(".search_title_text")
    addrs = driver.find_elements_by_css_selector(".address")
    for i in range(len(names)) :
        print(names[i].text,addrs[i].text, sep=", ", end="\n")
    print("------------------------------------------------")
    page += 1
    if page >= 3 and page <= 7 :        
        linkurl = '#panel   div.search_result > div > div > a:nth-child('+str(page)+')'
        try :
            linkNum = driver.find_element_by_css_selector(linkurl)
            print(linkNum.text + " 페이지") 
            linkNum.click()  
            time.sleep(5)
        except :
            break
    if page == 7 :
        page = 2
print("스크래핑 종료")
    




 