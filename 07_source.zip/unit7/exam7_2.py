#파일명 : exam7_2.py
from selenium import webdriver

driver = webdriver.Chrome('C:/Temp/chromedriver')
driver.implicitly_wait(5) 

driver.get("http://www.yes24.com/Product/goods/40936880")
import time
time.sleep(2)
try :
  readLinks = driver.find_elements_by_css_selector('#infoset_reviewContentList  div.btn_halfMore > a')

  for readlink in readLinks :
    readlink.click()
    time.sleep(1)

  reviewList = driver.find_elements_by_css_selector('#infoset_reviewContentList div.reviewInfoBot.origin div.review_cont')

  temp_list = []
  time.sleep(3)

  for review in reviewList :    
    temp_list.append(review.text)
  stopFlag = False
  while True :
    for n in range(4, 13) :
    #if n == 5 :
    #  continue
      linkurl = '#infoset_reviewContentList > div.review_sort.sortBot > div.review_sortLft > div > a:nth-child('+str(n)+')'
      linkNum = driver.find_element_by_css_selector(linkurl)
      linkNum.click()   
      time.sleep(3)
      readLinks = driver.find_elements_by_css_selector('#infoset_reviewContentList  div.btn_halfMore > a')
  
      for readlink in readLinks :
        #readlink.click()
        driver.execute_script("arguments[0].click();", readlink)
        time.sleep(3)
      
      reviewList = driver.find_elements_by_css_selector('#infoset_reviewContentList div.reviewInfoBot.origin div.review_cont')
      time.sleep(2)

      for review in reviewList :    
        temp_list.append(review.text)
    
      if len(reviewList) < 5 :
        stopFlag = True
        break
      
    if stopFlag == True :
      break
    nextPage = '#infoset_reviewContentList > div.review_sort.sortBot > div.review_sortLft > div > a.bgYUI.next'
    linkNum = driver.find_element_by_css_selector(nextPage)
    linkNum.click()
    time.sleep(1)
except Exception as ex:
  print("오류발생 : "+ex)
finally :
  driver.quit()

for item in temp_list :
    print(item)

wfile = open("c:/Temp/yes24file.txt","w") 
wfile.writelines(temp_list) 
wfile.close()



