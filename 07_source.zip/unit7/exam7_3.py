#파일명 : exam7_3.py
from selenium import webdriver

driver = webdriver.Chrome('C:/Temp/chromedriver')

driver.get('http://www.python.org/')
driver.implicitly_wait(3)
driver.get_screenshot_as_file('c:/Temp/python_main.png')
print('캡쳐 저장 완료')
import time
time.sleep(2)
driver.quit()
