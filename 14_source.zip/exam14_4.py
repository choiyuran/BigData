#날짜 연산하기 
import datetime

import calendar
start_day, last_day = calendar.monthrange(2019, 10)
print(start_day)
print(last_day)

for i in range(1,13):
    start_day, last_day = calendar.monthrange(2019, i)
    print( i,"월의 마지막날은 ", last_day, " 입니다")
