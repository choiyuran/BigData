import pandas as pd 
import numpy as np  

#날짜 문자열은 연도-월-일이 구분이 되면 된다. 
# 
date_str = ["2019-10-01", "2019-10-2", "2019/10/3", "20191004"]
idx = pd.to_datetime(date_str)

print(type(idx))
print(idx)

np.random.seed(0)
s = pd.Series(np.random.randn(4), index=idx)
print(s)

#인덱스를 이용하여 출력할 수 있다 
print( s['2019-10-01'])
print( s['2019-10-02'])
print( s['2019-10-03'])
print( s['2019-10-04'])

