import datetime

print("현재날짜와 시간 알아보기")
today = datetime.datetime.now()
print(today)

#내부구조 확인-클래스의 내부구조를 확인할 수 있다
print()
print(dir(datetime))
print()

#현재날짜 
print()
date_object = datetime.date.today()
print(date_object)

#연도, 월, 일 을 입력하여 date객체 생성하기
d = datetime.date(2019, 10, 13)
print(d)

#from 절을 이용하여 모듈을 import 한다 
#이럴경우에는 모듈명을 사용하지 않고 클래스명만으로 객체 생성이 가능하다
from datetime import date
a = date(2019, 10, 13)
print(a)

#timestamp로 부터 날짜 추출하기
value = 1567345678
timestamp = date.fromtimestamp(1567345678)
print("timestamp =", 1567345678)
print("Date =", timestamp)

#각 필드를 이용해 날짜와 시간 추출하기
today = datetime.datetime.now()
print(type(today))
print("년도 : ", today.year)
print("월 : ",today.month)
print("일 : ",today.day)

today = datetime.datetime.now()
print("시간 : ", today.hour)
print("분 : ",today.minute)
print("초 : ",today.second)


#요일  월요일:0, 화요일:1, 수요일:2, 목요일:3, 금요일:4, 토요일:5 일요일:6
weekday = ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"]
today = datetime.datetime.now()
print("요일 : ",today.weekday())
day =  today.weekday()
print("{0}-{1}-{2} 는 {3} 입니다".format(today.year,
         today.month, today.day, weekday[day]))

