import pandas as pd 
import numpy as np  

#2019년 9월 1일부터 2019년 9월 30일까지 생성
d = pd.date_range(start="2019-9-1", end="2019-9-30")
print(d)

d = pd.date_range(start="2019-1-1", periods=60)
print(d)

#2019년 1월중 일요일만 
d = pd.date_range(start="2019-10-1",  end="2019-10-30", freq='W')
print(d)

#2019년 각 달의 마지막날만 데이터 생성
np.random.seed(0)
ts = pd.Series(np.random.randn(12), 
    index=pd.date_range(start="2019-01-01", periods=12, freq="M"))
print(ts)

#resample 연산
ts = pd.Series(np.random.randn(100), 
    index=pd.date_range("2019-1-1", periods=100, freq="D"))
print(ts.tail(20))  #마지막 20개만 출력

print(ts.resample('W').mean()) #D(일일) -> W(주)형식으로 전환




