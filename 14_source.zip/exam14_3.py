import datetime

#서식 날짜데이터 바꾸기
today = datetime.datetime.now()
print(today)

print(today.strftime('%Y-%m-%d'))
print(today.strftime('%H:%M:%S'))
print(today.strftime('%Y-%m-%d %H:%M:%S'))

print(today.strftime('%Y-%m-%d %B'))
sDate = '2019-10-10 14:22:34'
#str형태의 날짜를 date 타입으로 전환하기 
date1 = datetime.datetime.strptime(sDate, '%Y-%m-%d %H:%M:%S')
print(type(date1)) 
print(date1)      


#타임존 
from datetime import datetime
import pytz
format = "%Y-%m-%d, %H:%M:%S"
local = datetime.now()
print("현재지역 :", local.strftime(format))
tz_NY = pytz.timezone('America/New_York') 
datetime_NY = datetime.now(tz_NY)
print("뉴욕시간 :", datetime_NY.strftime(format))
tz_London = pytz.timezone('Europe/London')
datetime_London = datetime.now(tz_London)
print("런던시간 :", datetime_London.strftime(format))
