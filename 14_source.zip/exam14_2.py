from datetime import datetime, date,  timedelta
d1 = date(2019,10, 13)
d2 = date(2019,12, 31)
#날짜연산
d3 = d2 - d1
print("올해 남은날", d3)
print("type of d3 =", type(d3)) 

t1 = datetime(year = 2019, month = 10, day = 19, hour = 7, minute = 9, second = 33)
t2 = datetime(year = 2019, month = 10, day = 19, hour = 5, minute = 1, second = 13)
t3 = t1 - t2
print("t3 =", t3)
print("type of t3 =", type(t3))  

#timedelta 사이의 연산
t1 = timedelta(weeks = 2, days = 5, hours = 1, seconds = 33)
t2 = timedelta(days = 4, hours = 11, minutes = 4, seconds = 54)
t3 = t1 - t2
print("t3 =", t3)

#음수값을 나타낼 수 도 있습니다.
t1 = timedelta(seconds = 33)
t2 = timedelta(seconds = 54)
t3 = t1 - t2
print("t3 =", t3)
print("t3 =", abs(t3))

#1일 2시간 33초 233밀리초를 초로 나타내기
t = timedelta(days = 1, hours = 2, seconds = 33, microseconds = 233)
print("total seconds =", t.total_seconds())

#지금 부터 3시간 뒤
current = datetime.today()
after = current + timedelta(hours=3)
print( current )
print( after )


