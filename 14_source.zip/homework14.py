from datetime import datetime, timedelta
import calendar

today = datetime.now()
yesterday = today  - timedelta(days=1)
tomorrow = today  + timedelta(days=1)

#1. 오늘 어제 내일
print("오늘 : ", today )     
print("어제 : ", yesterday)
print("내일 : ", tomorrow)


#2번.이달의 마지막날 
start_day, last_day = calendar.monthrange(today.year, today.month)
print("이달의 마지막 날은 ", last_day, "입니다")

#3번. 오늘은 무슨 요일인가요?
day =["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"]
print("오늘은 ", day[today.weekday()], "입니다")

#4번 이달의 마지막날까지 며칠남았습니까?
last_date = datetime(today.year, today.month, last_day)
period = last_date - today 
print( period, "남았습니다.")

