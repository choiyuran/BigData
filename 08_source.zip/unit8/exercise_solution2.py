#파일명 : exercise_solution2.py
import urllib.request
from bs4 import BeautifulSoup

client_key = '부여받은 Client ID'
client_secret = '부여받은 Client Secret'
query = '쌀국수'
encText = urllib.parse.quote_plus(query)

num = 30
naver_url = 'https://openapi.naver.com/v1/search/local.xml?query=' + encText + '&display=' + str(num)

request = urllib.request.Request(naver_url)
request.add_header("X-Naver-Client-Id",client_key)
request.add_header("X-Naver-Client-Secret",client_secret)
response = urllib.request.urlopen(request)

count = 1
rescode = response.getcode()
if(rescode == 200):
    print('[' + query + '집에 대한 네이버 지역 정보(XML) ]')
    response_body = response.read()
    response_body = response_body.decode('utf-8')
    soup = BeautifulSoup(response_body, 'xml')
    for itemList in soup.find_all('item') :
        title = itemList.find('title').string
        title = '없음' if title is None else title
        telephone = itemList.find('telephone').string
        telephone = '없음' if telephone is None else telephone
        address = itemList.find('address').string
        address = '없음' if address is None else address
        row = title + ',' + telephone + ',' + address
        print (str(count) + ' : ' + row)  
        count += 1     
else:
    print('오류 코드 : ' + rescode)
