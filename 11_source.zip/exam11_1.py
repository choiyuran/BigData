#파일명 : exam11_1.py

import pandas as pd 

#header가 3번째 줄에 있음 
data = pd.read_csv("./data/data.csv")

print("컬럼명 : ", data.columns)
print("인덱스 : ", data.index)

 
print( data.info() )

#누란된 데이터가 있는지 확인하자. 
print( data['height'].value_counts(dropna=False))
print( data['height'].isnull()) #NaN이면 True, 아니면 False반환
print( data['height'].notnull())


#null값인것에 대한 개수 확인 
print( data['height'].isnull().sum(axis=0))

# nan값을 thresh개 가진 열 모두 삭제 
data_thresh = data.dropna(axis=1, thresh=3)

#합계
print ( data['height'].sum() )

print("데이터 개수")
print(data.shape)
data = data.dropna(subset=['height'], how='any', axis=0)
print("삭제후 데이터개수")
print(data.shape)

data = data.dropna(subset=['weight'], how='any', axis=0)
print("삭제후 데이터개수")
print(data.shape)

#인덱스 다시 부여
data = data.reset_index(drop=True)
print(data)