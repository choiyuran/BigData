v1 = 5
v2 = 10
print(v1+v2)
print(v1*v2)
for i in range(v1, v2):
    print(i)
