import sys

for path in sys.path:
    print(path)