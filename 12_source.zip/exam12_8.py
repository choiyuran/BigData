#다른방법 
print("{} + {} = {}".format(3,4,3+4))
print("{1} + {0} = {2}".format(3,4,3+4))
print("{:.2f} X {:.2f} = {:.2f}".format(2.4, 3.5, 2.4*3.5))
print("{} is {}".format("flower", "beautiful"))

print("{:<5d}*".format(12))
print("{:>5d}*".format(12))

for i in range(1,6):
    print("{:04d}".format(i))

