#문자열(String)
msg1 = "Hello Python"
msg2 = 'Python is easy'

msg3 = """
나보기가 역겨워 가실때에는 
말없이 고이 보내드리우리다 
영변에 약산 진달래꽃 아름따다 
가실길에 뿌리오리다
"""

print(msg1)
print(msg2)
print(msg3)




 