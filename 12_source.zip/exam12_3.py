print()
print("\"파이썬\"은 데이터분석에 사용되는 언어입니다 ")
print("\'파이썬\'은 \'딥러닝\'에도 사용됩니다")
print("파이썬\n데이터분석\n크롤링")
print("파이썬\t데이터분석\t크롤링")
print("c:\\pythonwork_space\\exam12\\exam12_1.py")

msg = "파이썬\t뷰티플스프\n사이킷런"
print(msg)

path = r"c:\pythonwork_space\exam12\exam12_1.py"
print(path)

print()