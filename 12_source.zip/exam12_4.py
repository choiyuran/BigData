#문자열 연산하기 

print()
s1 = "Hello"
s2 = "Python"

s = s1 + " " + s2
print(s)

s = s1 * 3
print(s)

line = "-" * 50
print(line)

for i in range(1, 11):
    print("*" * i)
print()




 