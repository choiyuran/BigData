import pytagcloud
import webbrowser

tag = [('school',30), ('rainbow',10), ('cloud',23), ('peach',10), ('pink',20)]
#print(tag)
taglist = pytagcloud.make_tags(tag, maxsize=40)

#print(taglist)
pytagcloud.create_tag_image(taglist, 
                       'wordcloud.jpg', 
                       size=(300, 300), 
                       fontname='Nobile', rectangular=True)

#브라우저에 이미지를 보여준다                       
webbrowser.open('wordcloud.jpg')



