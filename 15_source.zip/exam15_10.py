# -*- coding: utf-8 -*-

#한글을 처리해 보자 

from os import path
from wordcloud import WordCloud
import nltk
from matplotlib import font_manager, rc, matplotlib_fname
import matplotlib.pyplot as plt

#한국 법률 말뭉치
from konlpy.corpus import kolaw
from konlpy.tag import  Twitter

#한국법률말뭉치로 부터 헌법을 읽어온다 
c = kolaw.open('constitution.txt').read()
print(c)

# Generate a word cloud image
wordcloud = WordCloud(font_path="c:/Windows/Fonts/malgun.ttf").generate(c)
wordcloud.to_file("image4.png")

plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.show()

