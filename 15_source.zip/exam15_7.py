import pytagcloud
import webbrowser
import random 

tag = [('학교',30), ('무지개',10), ('구름',23), ('복숭아',14), ('분홍색',20)]
#print(tag)
taglist = pytagcloud.make_tags(tag, maxsize=40)

random.seed(1234)

#print(taglist)
pytagcloud.create_tag_image(taglist, 
                       'wordcloud.jpg', 
                       size=(300, 300), 
                       fontname='HangleFont1', rectangular=True)

#브라우저에 이미지를 보여준다                       
webbrowser.open('wordcloud.jpg')
