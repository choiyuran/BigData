import matplotlib.pyplot as plt
from wordcloud import WordCloud

#1.txt 파일 읽기 
file = open("./data/alice.txt")
text = file.read()

#2. text 를 그대로 전달한다 
wordcloud = WordCloud().generate(text)

plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.show() 
