import pytagcloud
import webbrowser
from konlpy.tag import  Twitter
from collections import Counter

#1.txt 파일 읽기 

file = open("./data/data1.txt")
text = file.read()

#2.파일로 부터 명사를 추출한다 
twitter = Twitter()
nouns = twitter.nouns(text)

#3. Counter 클래스를 사용하여 단어와 단어의 빈도수를 카운트 한다 
nounsCount = Counter(nouns)
tag = nounsCount.most_common(100) #빈도수가 많은것 100개만 추출
taglist = pytagcloud.make_tags(tag, maxsize=100)

pytagcloud.create_tag_image(taglist, 
                       'wordcloud2.jpg', 
                       size=(400, 400), 
                       fontname='HangleFont1', 
                       rectangular=False)

#브라우저에 이미지를 보여준다                       
webbrowser.open('wordcloud2.jpg')
