from konlpy.corpus import kolaw, kobill 
wordList = kolaw.open('constitution.txt').readlines()
print(wordList[:3]) #3줄만 출력
print()
wordList2 = kobill.open('1809890.txt').readlines()
print(wordList2[:30]) #3줄만 출력

