from konlpy.tag import Kkma, Hannanum, Komoran, Mecab, Twitter
from konlpy.utils import pprint

file = open("./data/data1.txt")
msg = file.read()

print("--- Kkma 클래스 -----")
kkma = Kkma()
print("--- 문장으로 분해 --- ")
print(kkma.sentences(msg)) 

print("--- 명사분해 --- ")
print(kkma.nouns(msg))

print("--- 품사태깅 --- ")
print(kkma.pos(msg))


hannanum = Hannanum() 
print("--- 문장으로 분해 --- ")
print(hannanum.analyze(msg)) 
print("--- 형태소로 분해 --- ")
print(hannanum.morphs(msg)) 
print("--- 명사분해 --- ")
print(hannanum.nouns(msg))
print("--- 품사태깅 --- ")
print(hannanum.pos(msg))


twitter = Twitter()
print("--- Mecab 클래스 -----")
twitter = Twitter()
print("--- 형태소로 분해 --- ")
print(twitter.morphs(msg)) 
print("--- 명사분해 --- ")
print(twitter.nouns(msg))
print("--- 품사태깅 --- ")
print(twitter.pos(msg))

"""
-- 버그 있음
print("--- Komoran 클래스 -----")
komoran = Komoran()
print("--- 형태소로 분해 --- ")
print(komoran.morphs(msg)) 
print("--- 명사분해 --- ")
print(komoran.nouns(msg))
print("--- 품사태깅 --- ")
print(komoran.pos(msg))

--윈도우 지원 안함
print("--- Mecab 클래스 -----")
mecab = Mecab()
print("--- 형태소로 분해 --- ")
print(mecab.morphs(msg)) 
print("--- 명사분해 --- ")
print(mecab.nouns(msg))
print("--- 품사태깅 --- ")
print(mecab.pos(msg))
"""