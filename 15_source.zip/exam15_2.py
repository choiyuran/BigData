from konlpy.tag import  Hannanum
from konlpy.utils import pprint

msg = """
오픈소스를 이용하여 형태소 분석을 배워봅시다. 형태소 분석을 지원하는 라이브러리가 많습니다. 
각자 어떻게 분석하지는 살펴보겠습니다. 
이건 Hannanum 모듈입니다.
"""

hannanum = Hannanum() 
print(hannanum.analyze(msg)) 
print(hannanum.morphs(msg)) 
print(hannanum.nouns(msg))
print(hannanum.pos(msg))

